import { ReactNode } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface PageLayoutProps {
  children: ReactNode;
  currentPage: number;
  totalPages: number;
  onNext: () => void;
  onPrevious: () => void;
  onGoToPage: (page: number) => void;
}

/**
 * PageLayout - Wraps each page with navigation controls
 * Provides consistent layout and navigation across all pages
 */
const PageLayout = ({
  children,
  currentPage,
  totalPages,
  onNext,
  onPrevious,
  onGoToPage,
}: PageLayoutProps) => {
  return (
    <div className="page-container min-h-screen flex flex-col">
      {/* Header with page indicators */}
      <header className="flex justify-center py-4 mb-4">
        <div className="flex items-center gap-2">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => onGoToPage(i + 1)}
              className={`page-indicator cursor-pointer ${
                currentPage === i + 1
                  ? "page-indicator-active"
                  : "page-indicator-inactive"
              }`}
              aria-label={`Go to page ${i + 1}`}
            />
          ))}
        </div>
      </header>

      {/* Main content area */}
      <main className="flex-1 max-w-5xl mx-auto w-full animate-fade-in">
        {children}
      </main>

      {/* Navigation footer */}
      <footer className="py-6 mt-8">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <button
            onClick={onPrevious}
            disabled={currentPage === 1}
            className="nav-button-secondary flex items-center gap-2"
          >
            <ChevronLeft size={20} />
            <span className="hidden sm:inline">Previous</span>
          </button>

          <span className="text-muted-foreground font-medium">
            Page {currentPage} of {totalPages}
          </span>

          <button
            onClick={onNext}
            disabled={currentPage === totalPages}
            className="nav-button flex items-center gap-2"
          >
            <span className="hidden sm:inline">Next</span>
            <ChevronRight size={20} />
          </button>
        </div>
      </footer>
    </div>
  );
};

export default PageLayout;
