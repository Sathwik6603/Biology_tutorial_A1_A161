interface AntIconProps {
  size?: number;
  className?: string;
  animated?: boolean;
}

/**
 * AntIcon - SVG ant icon for use throughout the site
 * Can be animated with the crawl animation
 */
const AntIcon = ({ size = 24, className = "", animated = false }: AntIconProps) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      className={`ant-icon ${animated ? "animate-crawl" : ""} ${className}`}
    >
      {/* Ant body */}
      <ellipse cx="12" cy="16" rx="3" ry="4" />
      <ellipse cx="12" cy="10" rx="2.5" ry="2.5" />
      <ellipse cx="12" cy="5" rx="2" ry="2" />
      
      {/* Antennae */}
      <path
        d="M10 4 Q8 2 6 1"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M14 4 Q16 2 18 1"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      
      {/* Legs */}
      <path
        d="M9.5 11 Q7 10 5 8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M14.5 11 Q17 10 19 8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M9 14 Q6 14 4 12"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M15 14 Q18 14 20 12"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M9.5 17 Q7 18 5 20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M14.5 17 Q17 18 19 20"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
    </svg>
  );
};

export default AntIcon;
