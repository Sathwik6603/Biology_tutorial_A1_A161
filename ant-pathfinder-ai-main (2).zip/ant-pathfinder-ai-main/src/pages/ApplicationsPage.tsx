import { Shield, Network, Route, Bug, Database, Wifi } from "lucide-react";

/**
 * Page 4 - Applications
 * Real-world applications of ACO in security and optimization
 */
const ApplicationsPage = () => {
  const applications = [
    {
      icon: <Shield size={32} />,
      title: "Malware Detection Optimization",
      description:
        "ACO helps antivirus software find optimal signature patterns and efficiently scan large file systems by prioritizing high-risk areas.",
      example: "Kaspersky Lab has explored swarm intelligence for adaptive threat detection.",
      color: "primary",
    },
    {
      icon: <Network size={32} />,
      title: "Network Security",
      description:
        "Optimizing intrusion detection systems by finding the best combination of rules and thresholds to detect anomalies.",
      example: "ACO-based IDS can reduce false positives by 40% compared to traditional methods.",
      color: "secondary",
    },
    {
      icon: <Route size={32} />,
      title: "Routing Optimization",
      description:
        "Finding shortest paths in networks—from data packets to physical delivery routes. The original inspiration for ACO!",
      example: "AntNet protocol for adaptive routing in telecommunications networks.",
      color: "accent",
    },
  ];

  const moreApplications = [
    {
      icon: <Bug size={24} />,
      title: "Virus Signature Matching",
      description: "Optimizing pattern matching algorithms for faster malware identification",
    },
    {
      icon: <Database size={24} />,
      title: "Database Query Optimization",
      description: "Finding efficient query execution plans in large databases",
    },
    {
      icon: <Wifi size={24} />,
      title: "Wireless Sensor Networks",
      description: "Energy-efficient routing in IoT security applications",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="section-title">
          Real-World <span className="text-gradient-nature">Applications</span>
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          Where Ant Colony Optimization makes a difference
        </p>
      </div>

      {/* Main Applications */}
      <div className="space-y-6">
        {applications.map((app, index) => (
          <div key={index} className="content-card">
            <div className="flex flex-col md:flex-row gap-6">
              <div className="flex-shrink-0">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    app.color === "primary"
                      ? "icon-circle"
                      : app.color === "secondary"
                      ? "icon-circle-amber"
                      : "bg-accent"
                  }`}
                >
                  <span className="text-primary-foreground">{app.icon}</span>
                </div>
              </div>
              
              <div className="flex-1 space-y-3">
                <h2 className="text-xl font-semibold text-foreground">{app.title}</h2>
                <p className="text-muted-foreground leading-relaxed">{app.description}</p>
                <div className="info-box">
                  <p className="text-sm">
                    <strong>Real Example:</strong> {app.example}
                  </p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Additional Applications */}
      <div className="content-card">
        <h2 className="text-xl font-semibold mb-6">More Applications</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          {moreApplications.map((app, index) => (
            <div key={index} className="feature-card text-center">
              <div className="text-primary mb-3 flex justify-center">{app.icon}</div>
              <h3 className="font-semibold mb-2">{app.title}</h3>
              <p className="text-xs text-muted-foreground">{app.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ACO in Antivirus - Key Points */}
      <div className="content-card bg-primary/5 border-2 border-primary/20">
        <h2 className="text-xl font-semibold mb-4 text-primary">
          🛡️ ACO in Antivirus Software
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h3 className="font-semibold">Signature Optimization</h3>
            <p className="text-sm text-muted-foreground">
              ACO finds optimal virus signatures by treating each byte pattern as a "path" 
              and using pheromones to identify the most distinctive malware characteristics.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Scan Path Optimization</h3>
            <p className="text-sm text-muted-foreground">
              Instead of scanning every file sequentially, ACO prioritizes files based on 
              risk factors, reducing scan time while maintaining detection rates.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Behavior Analysis</h3>
            <p className="text-sm text-muted-foreground">
              ACO helps analyze program behavior patterns to detect zero-day threats 
              that don't match known signatures.
            </p>
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold">Resource Allocation</h3>
            <p className="text-sm text-muted-foreground">
              Optimizing how antivirus software uses CPU and memory during scans 
              for minimal system impact.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationsPage;
