import { useState, useCallback } from "react";
import PageLayout from "@/components/PageLayout";
import IntroductionPage from "@/pages/IntroductionPage";
import NatureInspirationPage from "@/pages/NatureInspirationPage";
import AlgorithmPage from "@/pages/AlgorithmPage";
import ApplicationsPage from "@/pages/ApplicationsPage";
import SimulationPage from "@/pages/SimulationPage";
import ConclusionPage from "@/pages/ConclusionPage";
import ThreatScanPage from "@/pages/ThreatScanPage";

/**
 * Index - Main page controller
 * Manages navigation between all 7 educational pages
 */
const Index = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 7;

  // Navigation handlers
  const handleNext = useCallback(() => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  }, []);

  const handlePrevious = useCallback(() => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  }, []);

  const handleGoToPage = useCallback((page: number) => {
    setCurrentPage(page);
  }, []);

  // Render current page content
  const renderPage = () => {
    switch (currentPage) {
      case 1:
        return <IntroductionPage />;
      case 2:
        return <NatureInspirationPage />;
      case 3:
        return <AlgorithmPage />;
      case 4:
        return <ApplicationsPage />;
      case 5:
        return <SimulationPage />;
      case 6:
        return <ThreatScanPage />;
      case 7:
        return <ConclusionPage />;
      default:
        return <IntroductionPage />;
    }
  };

  return (
    <PageLayout
      currentPage={currentPage}
      totalPages={totalPages}
      onNext={handleNext}
      onPrevious={handlePrevious}
      onGoToPage={handleGoToPage}
    >
      {renderPage()}
    </PageLayout>
  );
};

export default Index;
