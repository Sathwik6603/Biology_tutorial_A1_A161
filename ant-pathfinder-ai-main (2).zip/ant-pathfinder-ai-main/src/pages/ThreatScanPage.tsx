import { useState, useCallback } from "react";
import { Upload, Shield, ShieldAlert, ShieldCheck, Trash2, Download, AlertTriangle, FileWarning, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";

/**
 * Page 7 - File Threat Priority System
 * Educational simulation of file scanning and malware detection
 * NOTE: This is a SIMULATED system for educational purposes only
 */

// Threat types for simulation
const THREAT_TYPES = [
  "Trojan.Generic",
  "Worm.Autorun",
  "Adware.BrowserHijack",
  "Ransomware.Locker",
  "Spyware.KeyLogger",
  "Virus.FileInfector",
  "PUP.OptionalInstaller",
  "Backdoor.RemoteAccess",
];

// File extension risk levels (simulated)
const HIGH_RISK_EXTENSIONS = [".exe", ".bat", ".cmd", ".msi", ".scr", ".vbs", ".js"];
const MEDIUM_RISK_EXTENSIONS = [".zip", ".rar", ".7z", ".dll", ".jar"];
const LOW_RISK_EXTENSIONS = [".pdf", ".doc", ".docx", ".xls", ".xlsx"];

interface ScanResult {
  fileName: string;
  fileSize: number;
  fileType: string;
  hash: string;
  threatDetected: boolean;
  threatLevel: "none" | "low" | "medium" | "high";
  threatType: string | null;
  threatScore: number;
  scanTime: Date;
}

interface ScanHistoryItem extends ScanResult {
  id: string;
  action: "cleaned" | "discarded" | "pending";
}

const ThreatScanPage = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleaningProgress, setCleaningProgress] = useState(0);
  const [scanHistory, setScanHistory] = useState<ScanHistoryItem[]>([]);
  const [cleanedFileUrl, setCleanedFileUrl] = useState<string | null>(null);

  /**
   * Generate simulated SHA-256 hash (for educational display)
   */
  const generateSimulatedHash = (fileName: string): string => {
    const chars = "0123456789abcdef";
    let hash = "";
    const seed = fileName.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    for (let i = 0; i < 64; i++) {
      hash += chars[(seed * (i + 1) * 17) % 16];
    }
    return hash;
  };

  /**
   * Simulate threat detection based on file properties
   * NOTE: This is purely educational - no real scanning occurs
   */
  const simulateThreatDetection = useCallback((file: File): ScanResult => {
    const extension = "." + file.name.split(".").pop()?.toLowerCase();
    const hash = generateSimulatedHash(file.name);
    
    // Determine risk based on extension (simulated logic)
    let baseThreatScore = 0;
    let threatLevel: "none" | "low" | "medium" | "high" = "none";
    let threatDetected = false;
    let threatType: string | null = null;

    if (HIGH_RISK_EXTENSIONS.includes(extension)) {
      baseThreatScore = 60 + Math.random() * 40; // 60-100
    } else if (MEDIUM_RISK_EXTENSIONS.includes(extension)) {
      baseThreatScore = 30 + Math.random() * 40; // 30-70
    } else if (LOW_RISK_EXTENSIONS.includes(extension)) {
      baseThreatScore = Math.random() * 30; // 0-30
    } else {
      baseThreatScore = Math.random() * 50; // 0-50
    }

    // Add some randomness for demo purposes
    const randomFactor = Math.random();
    
    // 30% chance of threat for high-risk, 15% for medium, 5% for low
    if (HIGH_RISK_EXTENSIONS.includes(extension) && randomFactor < 0.3) {
      threatDetected = true;
    } else if (MEDIUM_RISK_EXTENSIONS.includes(extension) && randomFactor < 0.15) {
      threatDetected = true;
    } else if (randomFactor < 0.05) {
      threatDetected = true;
    }

    if (threatDetected) {
      if (baseThreatScore >= 70) {
        threatLevel = "high";
      } else if (baseThreatScore >= 40) {
        threatLevel = "medium";
      } else {
        threatLevel = "low";
      }
      threatType = THREAT_TYPES[Math.floor(Math.random() * THREAT_TYPES.length)];
    } else {
      baseThreatScore = Math.min(baseThreatScore, 20); // Safe files score low
    }

    return {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type || "unknown",
      hash,
      threatDetected,
      threatLevel,
      threatType,
      threatScore: Math.round(baseThreatScore),
      scanTime: new Date(),
    };
  }, []);

  /**
   * Handle file selection
   */
  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setScanResult(null);
      setCleanedFileUrl(null);
    }
  };

  /**
   * Handle drag and drop
   */
  const handleDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    const file = event.dataTransfer.files?.[0];
    if (file) {
      setSelectedFile(file);
      setScanResult(null);
      setCleanedFileUrl(null);
    }
  }, []);

  /**
   * Start file scan simulation
   */
  const startScan = async () => {
    if (!selectedFile) return;

    setIsScanning(true);
    setScanProgress(0);
    setScanResult(null);

    // Simulate scanning progress
    for (let i = 0; i <= 100; i += 5) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      setScanProgress(i);
    }

    // Generate simulated result
    const result = simulateThreatDetection(selectedFile);
    setScanResult(result);
    setIsScanning(false);

    // Add to history
    const historyItem: ScanHistoryItem = {
      ...result,
      id: Date.now().toString(),
      action: "pending",
    };
    setScanHistory((prev) => [historyItem, ...prev.slice(0, 9)]);
  };

  /**
   * Simulate virus cleaning process
   */
  const cleanVirus = async () => {
    if (!selectedFile || !scanResult) return;

    setIsCleaning(true);
    setCleaningProgress(0);

    // Simulate cleaning progress
    for (let i = 0; i <= 100; i += 2) {
      await new Promise((resolve) => setTimeout(resolve, 50));
      setCleaningProgress(i);
    }

    // Create a "cleaned" version (simulated - just creates a text file)
    const cleanedContent = `[CLEANED FILE]\nOriginal: ${selectedFile.name}\nThreat Removed: ${scanResult.threatType}\nCleaned at: ${new Date().toISOString()}\n\nThis is a simulated cleaned file for educational purposes.`;
    const blob = new Blob([cleanedContent], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    setCleanedFileUrl(url);

    // Update history
    setScanHistory((prev) =>
      prev.map((item) =>
        item.id === scanHistory[0]?.id ? { ...item, action: "cleaned" } : item
      )
    );

    setIsCleaning(false);
  };

  /**
   * Discard infected file
   */
  const discardFile = () => {
    // Update history
    setScanHistory((prev) =>
      prev.map((item) =>
        item.id === scanHistory[0]?.id ? { ...item, action: "discarded" } : item
      )
    );

    setSelectedFile(null);
    setScanResult(null);
    setCleanedFileUrl(null);
  };

  /**
   * Format file size for display
   */
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  };

  /**
   * Get threat level color
   */
  const getThreatColor = (level: string): string => {
    switch (level) {
      case "high":
        return "text-red-500";
      case "medium":
        return "text-orange-500";
      case "low":
        return "text-yellow-500";
      default:
        return "text-green-500";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="section-title">
          File <span className="text-gradient-pheromone">Threat Priority</span> System
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          Educational simulation of ACO-inspired file threat detection and prioritization
        </p>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 text-secondary text-sm">
          <ShieldCheck size={16} />
          <span>Simulated scanning - No real malware detection</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Upload & Scan Section */}
        <div className="lg:col-span-2 space-y-6">
          {/* File Upload Area */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload size={20} />
                Upload File for Scanning
              </CardTitle>
              <CardDescription>
                Drop any file here to simulate threat detection
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                className="border-2 border-dashed border-muted-foreground/30 rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
              >
                <input
                  type="file"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-lg font-medium mb-2">
                    {selectedFile ? selectedFile.name : "Drop file here or click to browse"}
                  </p>
                  {selectedFile && (
                    <p className="text-sm text-muted-foreground">
                      {formatFileSize(selectedFile.size)} • {selectedFile.type || "Unknown type"}
                    </p>
                  )}
                </label>
              </div>

              {selectedFile && !isScanning && !scanResult && (
                <Button onClick={startScan} className="w-full mt-4" size="lg">
                  <Shield className="mr-2" size={18} />
                  Start Threat Scan
                </Button>
              )}

              {/* Scanning Progress */}
              {isScanning && (
                <div className="mt-6 space-y-3">
                  <div className="flex items-center gap-3">
                    <Loader2 className="animate-spin text-primary" size={20} />
                    <span className="font-medium">Scanning file...</span>
                    <span className="ml-auto text-muted-foreground">{scanProgress}%</span>
                  </div>
                  <Progress value={scanProgress} className="h-3" />
                  <p className="text-sm text-muted-foreground text-center">
                    Analyzing file structure and patterns...
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Scan Result */}
          {scanResult && (
            <Card className={scanResult.threatDetected ? "border-red-500/50" : "border-green-500/50"}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {scanResult.threatDetected ? (
                    <>
                      <ShieldAlert className="text-red-500" size={24} />
                      <span className="text-red-500">Threat Detected!</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="text-green-500" size={24} />
                      <span className="text-green-500">No Threat Detected</span>
                    </>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* File Info */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">File Name</p>
                    <p className="font-medium truncate">{scanResult.fileName}</p>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">File Size</p>
                    <p className="font-medium">{formatFileSize(scanResult.fileSize)}</p>
                  </div>
                </div>

                {/* Hash Display */}
                <div className="p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">SHA-256 Hash (Simulated)</p>
                  <p className="font-mono text-xs break-all">{scanResult.hash}</p>
                </div>

                {/* Threat Info */}
                {scanResult.threatDetected && (
                  <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg space-y-3">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="text-red-500" size={20} />
                      <div>
                        <p className="font-semibold">{scanResult.threatType}</p>
                        <p className={`text-sm font-medium ${getThreatColor(scanResult.threatLevel)}`}>
                          Threat Level: {scanResult.threatLevel.toUpperCase()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Priority Score:</span>
                      <Progress value={scanResult.threatScore} className="flex-1 h-2" />
                      <span className="font-bold">{scanResult.threatScore}/100</span>
                    </div>
                  </div>
                )}

                {/* Threat Score for safe files */}
                {!scanResult.threatDetected && (
                  <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 className="text-green-500" size={18} />
                      <span className="font-medium">File is safe</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">Risk Score:</span>
                      <Progress value={scanResult.threatScore} className="flex-1 h-2" />
                      <span className="font-bold text-green-600">{scanResult.threatScore}/100</span>
                    </div>
                  </div>
                )}

                {/* Action Buttons for threats */}
                {scanResult.threatDetected && !isCleaning && !cleanedFileUrl && (
                  <div className="flex gap-3 pt-4">
                    <Button onClick={cleanVirus} variant="default" className="flex-1">
                      <ShieldCheck className="mr-2" size={18} />
                      Clear Virus
                    </Button>
                    <Button onClick={discardFile} variant="destructive" className="flex-1">
                      <Trash2 className="mr-2" size={18} />
                      Discard File
                    </Button>
                  </div>
                )}

                {/* Cleaning Progress */}
                {isCleaning && (
                  <div className="space-y-3 pt-4">
                    <div className="flex items-center gap-3">
                      <Loader2 className="animate-spin text-green-500" size={20} />
                      <span className="font-medium">Cleaning virus...</span>
                      <span className="ml-auto">{cleaningProgress}%</span>
                    </div>
                    <Progress value={cleaningProgress} className="h-3" />
                  </div>
                )}

                {/* Download Cleaned File */}
                {cleanedFileUrl && (
                  <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="text-green-500" size={24} />
                      <div className="flex-1">
                        <p className="font-semibold text-green-600">Virus Removed Successfully!</p>
                        <p className="text-sm text-muted-foreground">
                          Your file has been cleaned and is safe to download
                        </p>
                      </div>
                      <a
                        href={cleanedFileUrl}
                        download={`cleaned_${scanResult.fileName}.txt`}
                        className="inline-flex"
                      >
                        <Button variant="outline" size="sm">
                          <Download className="mr-2" size={16} />
                          Download
                        </Button>
                      </a>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Scan History */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileWarning size={18} />
                Scan History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                {scanHistory.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    No scans yet. Upload a file to begin.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {scanHistory.map((item) => (
                      <div
                        key={item.id}
                        className="p-3 bg-muted/30 rounded-lg border-l-4"
                        style={{
                          borderLeftColor: item.threatDetected
                            ? item.threatLevel === "high"
                              ? "#ef4444"
                              : item.threatLevel === "medium"
                              ? "#f97316"
                              : "#eab308"
                            : "#22c55e",
                        }}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-medium text-sm truncate flex-1">
                            {item.fileName}
                          </p>
                          {item.threatDetected ? (
                            <XCircle size={16} className="text-red-500 shrink-0" />
                          ) : (
                            <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">
                            Score: {item.threatScore}
                          </span>
                          {item.action !== "pending" && (
                            <span
                              className={`text-xs px-2 py-0.5 rounded-full ${
                                item.action === "cleaned"
                                  ? "bg-green-500/20 text-green-600"
                                  : "bg-red-500/20 text-red-600"
                              }`}
                            >
                              {item.action}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {item.scanTime.toLocaleTimeString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Educational Note */}
      <Card className="bg-muted/30">
        <CardContent className="py-4">
          <div className="flex items-start gap-3">
            <Shield className="text-primary shrink-0 mt-0.5" size={20} />
            <div>
              <p className="font-semibold mb-1">Educational Simulation</p>
              <p className="text-sm text-muted-foreground">
                This system demonstrates how ACO-inspired algorithms can prioritize threat detection.
                File analysis is simulated based on file extension patterns. No real malware scanning
                or harmful operations occur. In production systems, actual scanning engines would
                analyze file signatures, behavior patterns, and heuristic indicators.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ThreatScanPage;
