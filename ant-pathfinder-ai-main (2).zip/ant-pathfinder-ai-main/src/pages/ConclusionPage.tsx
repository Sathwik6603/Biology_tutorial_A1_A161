import AntIcon from "@/components/AntIcon";
import { CheckCircle, Zap, Shield, Lightbulb, Rocket, Leaf } from "lucide-react";

/**
 * Page 6 - Conclusion
 * Summary of ACO advantages and future scope
 */
const ConclusionPage = () => {
  const advantages = [
    {
      icon: <Zap size={24} />,
      title: "Parallelizable",
      description: "Multiple ants explore simultaneously, enabling efficient parallel processing.",
    },
    {
      icon: <Shield size={24} />,
      title: "Robust",
      description: "Works well even with incomplete or noisy data—perfect for real-world security.",
    },
    {
      icon: <CheckCircle size={24} />,
      title: "Self-Organizing",
      description: "No central control needed; optimal solutions emerge from collective behavior.",
    },
    {
      icon: <Lightbulb size={24} />,
      title: "Adaptive",
      description: "Continuously adapts to changes in the problem space through pheromone dynamics.",
    },
  ];

  const futureScope = [
    "Deep Learning + ACO hybrid systems for advanced threat detection",
    "Quantum-inspired ant colony algorithms for cryptographic applications",
    "Multi-objective ACO for balancing security, performance, and resource usage",
    "Real-time adaptive antivirus systems using swarm intelligence",
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-6">
        <div className="flex justify-center">
          <div className="relative">
            <div className="icon-circle w-20 h-20 animate-float">
              <AntIcon size={40} className="text-primary-foreground" />
            </div>
          </div>
        </div>
        <h1 className="section-title">
          <span className="text-gradient-nature">Conclusion</span>
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          The power of nature-inspired computing for modern cybersecurity
        </p>
      </div>

      {/* Summary */}
      <div className="content-card space-y-4">
        <h2 className="text-xl font-semibold text-foreground">
          What We've Learned
        </h2>
        <p className="text-muted-foreground leading-relaxed">
          Ant Colony Optimization represents a powerful paradigm in computational 
          intelligence. By mimicking the <span className="pheromone-text">collective behavior of ant colonies</span>, 
          we can solve complex optimization problems that traditional algorithms struggle with. 
          In the context of antivirus software, ACO offers a dynamic, adaptive approach to 
          threat detection and system optimization.
        </p>
      </div>

      {/* Advantages Grid */}
      <div className="content-card">
        <h2 className="text-xl font-semibold mb-6">Key Advantages of ACO</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          {advantages.map((adv, index) => (
            <div key={index} className="feature-card flex gap-4">
              <div className="icon-circle-amber flex-shrink-0">
                <span className="text-primary-foreground">{adv.icon}</span>
              </div>
              <div>
                <h3 className="font-semibold mb-1">{adv.title}</h3>
                <p className="text-sm text-muted-foreground">{adv.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Why Effective for Antivirus */}
      <div className="content-card bg-primary/5 border-2 border-primary/20">
        <div className="flex items-center gap-3 mb-4">
          <Shield className="text-primary" size={28} />
          <h2 className="text-xl font-semibold text-primary">
            Why ACO is Effective for Antivirus
          </h2>
        </div>
        <ul className="space-y-3">
          <li className="flex items-start gap-2">
            <CheckCircle className="text-accent flex-shrink-0 mt-1" size={18} />
            <span className="text-muted-foreground">
              <strong className="text-foreground">Dynamic adaptation:</strong> Malware evolves 
              constantly; ACO's adaptive nature helps keep up with new threats.
            </span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="text-accent flex-shrink-0 mt-1" size={18} />
            <span className="text-muted-foreground">
              <strong className="text-foreground">Efficient search:</strong> Instead of exhaustively 
              scanning everything, ACO prioritizes high-risk areas.
            </span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="text-accent flex-shrink-0 mt-1" size={18} />
            <span className="text-muted-foreground">
              <strong className="text-foreground">Pattern recognition:</strong> ACO excels at finding 
              patterns in complex data—essential for signature matching.
            </span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="text-accent flex-shrink-0 mt-1" size={18} />
            <span className="text-muted-foreground">
              <strong className="text-foreground">Resource optimization:</strong> Minimal computational 
              overhead while maintaining high detection rates.
            </span>
          </li>
        </ul>
      </div>

      {/* Future Scope */}
      <div className="content-card">
        <div className="flex items-center gap-3 mb-6">
          <Rocket className="text-secondary" size={28} />
          <h2 className="text-xl font-semibold">Future Scope</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {futureScope.map((item, index) => (
            <div key={index} className="info-box">
              <div className="flex items-center gap-2">
                <Lightbulb className="text-secondary flex-shrink-0" size={16} />
                <p className="text-sm">{item}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Final Message */}
      <div className="text-center space-y-4 py-6">
        <div className="flex justify-center gap-2">
          <AntIcon size={20} animated />
          <AntIcon size={20} animated />
          <AntIcon size={20} animated />
        </div>
        <p className="text-lg font-medium text-primary">
          "In nature's algorithms, we find elegant solutions to our most complex problems."
        </p>
        <div className="flex items-center justify-center gap-2 text-muted-foreground">
          <Leaf size={16} />
          <span className="text-sm">Bio-Inspired Computing for a Safer Digital World</span>
        </div>
      </div>
    </div>
  );
};

export default ConclusionPage;
