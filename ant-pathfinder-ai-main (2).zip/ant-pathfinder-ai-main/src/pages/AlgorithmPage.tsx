import { ArrowDown, RefreshCw, Route, Droplets, CheckCircle } from "lucide-react";

/**
 * Page 3 - How the Algorithm Works
 * Step-by-step explanation with flow diagram
 */
const AlgorithmPage = () => {
  const steps = [
    {
      id: 1,
      title: "Initialization",
      icon: <RefreshCw size={24} />,
      description: "Set initial pheromone values on all paths. Place ants at starting positions.",
      details: "All paths start with equal pheromone levels (typically a small value like 0.1)",
    },
    {
      id: 2,
      title: "Path Selection",
      icon: <Route size={24} />,
      description: "Each ant probabilistically chooses the next node based on pheromone levels and heuristic information.",
      details: "Probability = (Pheromone^α) × (Heuristic^β) / Sum of all options",
    },
    {
      id: 3,
      title: "Solution Construction",
      icon: <CheckCircle size={24} />,
      description: "Ants continue selecting paths until they complete their tour (visit all required nodes).",
      details: "Each ant builds a complete solution independently",
    },
    {
      id: 4,
      title: "Pheromone Update",
      icon: <Droplets size={24} />,
      description: "Better solutions deposit more pheromones. All pheromones evaporate partially.",
      details: "Evaporation rate (ρ) typically between 0.1 and 0.5",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="section-title">
          How the <span className="text-gradient-pheromone">Algorithm</span> Works
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          Understanding Ant Colony Optimization step by step
        </p>
      </div>

      {/* Flow Diagram */}
      <div className="content-card">
        <h2 className="text-xl font-semibold mb-6 text-center">ACO Algorithm Flow</h2>
        
        <div className="flex flex-col items-center space-y-4">
          {steps.map((step, index) => (
            <div key={step.id} className="w-full max-w-md">
              {/* Step node */}
              <div className="flow-node">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <div className={`${index === 3 ? 'icon-circle-amber' : 'icon-circle'} w-10 h-10`}>
                    <span className="text-primary-foreground">{step.icon}</span>
                  </div>
                  <h3 className="font-semibold text-lg">{step.title}</h3>
                </div>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </div>
              
              {/* Arrow (except after last step) */}
              {index < steps.length - 1 && (
                <div className="flex justify-center py-2">
                  <ArrowDown className="text-secondary" size={28} />
                </div>
              )}
            </div>
          ))}
          
          {/* Loop back arrow */}
          <div className="flex items-center gap-2 text-primary mt-4">
            <RefreshCw size={20} />
            <span className="text-sm font-medium">Repeat until termination condition met</span>
          </div>
        </div>
      </div>

      {/* Detailed Steps */}
      <div className="grid md:grid-cols-2 gap-6">
        {steps.map((step) => (
          <div key={step.id} className="feature-card">
            <div className="flex items-center gap-3 mb-3">
              <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                {step.id}
              </span>
              <h3 className="font-semibold text-foreground">{step.title}</h3>
            </div>
            <p className="text-muted-foreground text-sm mb-3">{step.description}</p>
            <div className="info-box">
              <p className="text-xs font-mono">{step.details}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Key Parameters */}
      <div className="content-card">
        <h2 className="text-xl font-semibold mb-4">Key Parameters</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-muted/30 rounded-xl">
            <p className="text-2xl font-bold text-primary mb-1">α</p>
            <p className="text-sm text-muted-foreground">Pheromone importance</p>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-xl">
            <p className="text-2xl font-bold text-secondary mb-1">β</p>
            <p className="text-sm text-muted-foreground">Heuristic importance</p>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-xl">
            <p className="text-2xl font-bold text-accent mb-1">ρ</p>
            <p className="text-sm text-muted-foreground">Evaporation rate</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlgorithmPage;
