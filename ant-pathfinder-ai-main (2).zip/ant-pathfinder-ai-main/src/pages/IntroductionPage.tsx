import AntIcon from "@/components/AntIcon";
import { Shield, Bug, Zap, Network } from "lucide-react";

/**
 * Page 1 - Introduction
 * Introduces ACO algorithms and their relevance to antivirus optimization
 */
const IntroductionPage = () => {
  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center space-y-6">
        <div className="flex justify-center mb-6">
          <div className="relative">
            <div className="icon-circle-amber w-20 h-20 animate-float">
              <AntIcon size={40} className="text-primary-foreground" />
            </div>
            {/* Decorative pheromone trails */}
            <div className="absolute -left-8 top-1/2 w-6 h-1 bg-secondary/40 rounded-full" />
            <div className="absolute -right-8 top-1/2 w-6 h-1 bg-secondary/40 rounded-full" />
          </div>
        </div>
        
        <h1 className="section-title">
          Ant Colony Based Algorithms in{" "}
          <span className="text-gradient-nature">Antivirus Optimization</span>
        </h1>
        
        <p className="section-subtitle max-w-3xl mx-auto">
          Discover how nature's tiny engineers inspire powerful solutions for cybersecurity
        </p>
      </div>

      {/* Content Cards */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* What are Optimization Problems? */}
        <div className="content-card space-y-4">
          <div className="flex items-center gap-3">
            <div className="icon-circle">
              <Zap size={24} className="text-primary-foreground" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">
              What are Optimization Problems?
            </h2>
          </div>
          
          <p className="text-muted-foreground leading-relaxed">
            Optimization problems involve finding the <span className="pheromone-text">best solution</span> from 
            all possible options. In computing, this could mean finding the fastest route, 
            most efficient schedule, or in our case—the most effective way to detect malware.
          </p>
          
          <div className="info-box">
            <p className="text-sm text-foreground">
              <strong>Example:</strong> Finding the shortest path through a network of 
              millions of files to identify threats efficiently.
            </p>
          </div>
        </div>

        {/* Why Bio-Inspired Algorithms? */}
        <div className="content-card space-y-4">
          <div className="flex items-center gap-3">
            <div className="icon-circle">
              <Bug size={24} className="text-primary-foreground" />
            </div>
            <h2 className="text-xl font-semibold text-foreground">
              Why Bio-Inspired Algorithms?
            </h2>
          </div>
          
          <p className="text-muted-foreground leading-relaxed">
            Nature has spent millions of years perfecting solutions to complex problems. 
            By studying <span className="pheromone-text">ant colonies</span>, we can apply 
            their collective intelligence to solve modern cybersecurity challenges.
          </p>
          
          <div className="info-box">
            <p className="text-sm text-foreground">
              <strong>Key Insight:</strong> Ants find optimal paths without central 
              coordination—perfect for distributed threat detection!
            </p>
          </div>
        </div>
      </div>

      {/* Why ACO for Antivirus */}
      <div className="content-card space-y-6">
        <div className="flex items-center gap-3">
          <div className="icon-circle-amber">
            <Shield size={24} className="text-primary-foreground" />
          </div>
          <h2 className="text-xl font-semibold text-foreground">
            Importance in Cybersecurity
          </h2>
        </div>

        <div className="grid sm:grid-cols-3 gap-4">
          <div className="feature-card text-center">
            <Network className="mx-auto mb-3 text-primary" size={32} />
            <h3 className="font-semibold mb-2">Adaptive</h3>
            <p className="text-sm text-muted-foreground">
              Continuously learns and adapts to new malware patterns
            </p>
          </div>
          
          <div className="feature-card text-center">
            <Zap className="mx-auto mb-3 text-secondary" size={32} />
            <h3 className="font-semibold mb-2">Efficient</h3>
            <p className="text-sm text-muted-foreground">
              Finds optimal solutions faster than traditional methods
            </p>
          </div>
          
          <div className="feature-card text-center">
            <Bug className="mx-auto mb-3 text-accent" size={32} />
            <h3 className="font-semibold mb-2">Robust</h3>
            <p className="text-sm text-muted-foreground">
              Works well even with incomplete information
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntroductionPage;
