import AntIcon from "@/components/AntIcon";
import { ArrowRight, Droplets } from "lucide-react";

/**
 * Page 2 - Inspiration from Nature
 * Explains how real ants find shortest paths using pheromones
 */
const NatureInspirationPage = () => {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="section-title">
          Inspiration from <span className="text-gradient-nature">Nature</span>
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          How tiny ants solve complex problems that challenge supercomputers
        </p>
      </div>

      {/* Ant Path Finding Explanation */}
      <div className="content-card space-y-6">
        <h2 className="text-2xl font-semibold text-foreground flex items-center gap-3">
          <AntIcon size={28} animated />
          How Ants Find the Shortest Path
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Visual representation */}
          <div className="bg-muted/30 rounded-xl p-6 flex flex-col items-center justify-center min-h-[250px]">
            {/* Simple visual of nest to food with two paths */}
            <div className="relative w-full max-w-[280px]">
              {/* Nest */}
              <div className="absolute left-0 top-1/2 -translate-y-1/2 bg-nest text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center">
                <span className="text-xs font-semibold">Nest</span>
              </div>
              
              {/* Food */}
              <div className="absolute right-0 top-1/2 -translate-y-1/2 bg-food text-primary-foreground rounded-full w-16 h-16 flex items-center justify-center">
                <span className="text-xs font-semibold">Food</span>
              </div>
              
              {/* Long path (top) */}
              <svg className="absolute w-full h-32 top-0 -translate-y-1/2" viewBox="0 0 280 80">
                <path
                  d="M 40 60 Q 140 0 240 60"
                  fill="none"
                  stroke="hsl(30, 20%, 75%)"
                  strokeWidth="3"
                  strokeDasharray="5,5"
                />
                <text x="140" y="25" textAnchor="middle" className="text-xs fill-muted-foreground">
                  Long Path
                </text>
              </svg>
              
              {/* Short path (bottom) - highlighted */}
              <svg className="absolute w-full h-32 bottom-0 translate-y-1/2" viewBox="0 0 280 80">
                <path
                  d="M 40 20 L 240 20"
                  fill="none"
                  stroke="hsl(35, 90%, 50%)"
                  strokeWidth="4"
                  className="animate-pulse-soft"
                />
                <text x="140" y="45" textAnchor="middle" className="text-xs fill-secondary font-semibold">
                  Short Path (More Pheromones!)
                </text>
              </svg>
              
              {/* Ants on short path */}
              <div className="absolute left-1/4 bottom-1/2 translate-y-1">
                <AntIcon size={16} animated />
              </div>
              <div className="absolute left-1/2 bottom-1/2 translate-y-1 -translate-x-1/2">
                <AntIcon size={16} animated />
              </div>
              <div className="absolute right-1/4 bottom-1/2 translate-y-1">
                <AntIcon size={16} animated />
              </div>
            </div>
          </div>

          {/* Step by step explanation */}
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                1
              </span>
              <div>
                <h3 className="font-semibold">Random Exploration</h3>
                <p className="text-sm text-muted-foreground">
                  Scout ants leave the nest and explore randomly, leaving pheromone trails.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                2
              </span>
              <div>
                <h3 className="font-semibold">Path Discovery</h3>
                <p className="text-sm text-muted-foreground">
                  Some ants find food faster via shorter routes, returning quickly to reinforce their trail.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <span className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center font-semibold">
                3
              </span>
              <div>
                <h3 className="font-semibold">Pheromone Buildup</h3>
                <p className="text-sm text-muted-foreground">
                  Shorter paths accumulate more pheromones faster, attracting more ants.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <span className="flex-shrink-0 w-8 h-8 rounded-full bg-accent text-accent-foreground flex items-center justify-center font-semibold">
                4
              </span>
              <div>
                <h3 className="font-semibold">Optimal Convergence</h3>
                <p className="text-sm text-muted-foreground">
                  Eventually, most ants follow the shortest path—the one with strongest pheromones.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pheromone Concept */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="content-card space-y-4">
          <div className="flex items-center gap-3">
            <div className="icon-circle-amber">
              <Droplets size={24} className="text-primary-foreground" />
            </div>
            <h2 className="text-xl font-semibold">What are Pheromones?</h2>
          </div>
          
          <p className="text-muted-foreground leading-relaxed">
            Pheromones are <span className="pheromone-text">chemical signals</span> that ants 
            deposit as they walk. Other ants can smell these trails and are more likely to 
            follow paths with stronger pheromone concentrations.
          </p>
          
          <div className="info-box">
            <p className="text-sm">
              <strong>Key Property:</strong> Pheromones evaporate over time! This prevents 
              the colony from getting stuck on old, suboptimal paths.
            </p>
          </div>
        </div>

        <div className="content-card space-y-4">
          <div className="flex items-center gap-3">
            <div className="icon-circle">
              <ArrowRight size={24} className="text-primary-foreground" />
            </div>
            <h2 className="text-xl font-semibold">Connection to Computing</h2>
          </div>
          
          <p className="text-muted-foreground leading-relaxed">
            In algorithms, pheromones become <span className="pheromone-text">numerical values</span> that 
            guide decision-making. Higher values indicate better solutions, while evaporation 
            allows the algorithm to explore new possibilities.
          </p>
          
          <div className="info-box">
            <p className="text-sm">
              <strong>Translation:</strong> Ant behavior → Mathematical model → 
              Optimization algorithm → Antivirus solution!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NatureInspirationPage;
