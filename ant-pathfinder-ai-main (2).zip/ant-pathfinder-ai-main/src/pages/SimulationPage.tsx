import { useEffect, useRef, useState, useCallback } from "react";
import { Play, Pause, RotateCcw, Zap } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";

/**
 * Page 5 - Interactive ACO Simulation
 * Visual demonstration of ants finding shortest path with pheromone trails
 * Shows step-by-step iterations and execution log
 */

// Type definitions for simulation
interface Point {
  x: number;
  y: number;
}

interface Ant {
  x: number;
  y: number;
  path: number[];
  returning: boolean;
  currentNode: number;
  targetNode: number;
  progress: number;
}

interface Edge {
  from: number;
  to: number;
  pheromone: number;
  distance: number;
}

interface IterationLog {
  iteration: number;
  bestPath: number[];
  bestDistance: number;
  avgPheromone: number;
  timestamp: Date;
}

const SimulationPage = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [iteration, setIteration] = useState(0);
  const [shortestPath, setShortestPath] = useState<number[]>([]);
  const [bestDistance, setBestDistance] = useState<number | null>(null);
  const [iterationLogs, setIterationLogs] = useState<IterationLog[]>([]);
  const [currentPhase, setCurrentPhase] = useState<string>("Initialization");
  const [antsCompleted, setAntsCompleted] = useState(0);

  // Simulation state refs
  const nodesRef = useRef<Point[]>([]);
  const edgesRef = useRef<Edge[]>([]);
  const antsRef = useRef<Ant[]>([]);

  // Configuration
  const NUM_ANTS = 10;
  const EVAPORATION_RATE = 0.1;
  const ALPHA = 1; // Pheromone importance
  const BETA = 2; // Heuristic importance
  const Q = 100; // Pheromone deposit factor

  /**
   * Initialize the simulation graph
   */
  const initializeSimulation = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.width;
    const height = canvas.height;

    // Create nodes: nest (0), food (last), and intermediate nodes
    const nodes: Point[] = [
      { x: 50, y: height / 2 }, // Nest
      { x: width / 4, y: height / 4 }, // Upper path nodes
      { x: width / 2, y: height / 6 },
      { x: (3 * width) / 4, y: height / 4 },
      { x: width / 4, y: (3 * height) / 4 }, // Lower path nodes
      { x: width / 2, y: (5 * height) / 6 },
      { x: (3 * width) / 4, y: (3 * height) / 4 },
      { x: width / 4, y: height / 2 }, // Middle path (shorter)
      { x: (3 * width) / 4, y: height / 2 },
      { x: width - 50, y: height / 2 }, // Food
    ];

    nodesRef.current = nodes;

    // Create edges with distances
    const connections = [
      [0, 1], [0, 4], [0, 7], // From nest
      [1, 2], [2, 3], [3, 9], // Upper path
      [4, 5], [5, 6], [6, 9], // Lower path
      [7, 8], [8, 9], // Middle path (shortest)
      [1, 7], [7, 4], // Cross connections
      [3, 8], [8, 6], // Cross connections
    ];

    const edges: Edge[] = connections.map(([from, to]) => {
      const dx = nodes[to].x - nodes[from].x;
      const dy = nodes[to].y - nodes[from].y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      return {
        from,
        to,
        pheromone: 0.1,
        distance,
      };
    });

    edgesRef.current = edges;

    // Initialize ants at nest
    antsRef.current = Array.from({ length: NUM_ANTS }, () => ({
      x: nodes[0].x,
      y: nodes[0].y,
      path: [0],
      returning: false,
      currentNode: 0,
      targetNode: -1,
      progress: 0,
    }));

    setIteration(0);
    setShortestPath([]);
    setBestDistance(null);
    setIterationLogs([]);
    setCurrentPhase("Initialization");
    setAntsCompleted(0);
  }, []);

  /**
   * Get adjacent nodes and their edges
   */
  const getNeighbors = (nodeIndex: number): { node: number; edge: Edge }[] => {
    const neighbors: { node: number; edge: Edge }[] = [];
    edgesRef.current.forEach((edge) => {
      if (edge.from === nodeIndex) {
        neighbors.push({ node: edge.to, edge });
      } else if (edge.to === nodeIndex) {
        neighbors.push({ node: edge.from, edge });
      }
    });
    return neighbors;
  };

  /**
   * Select next node based on pheromone and heuristic
   */
  const selectNextNode = (ant: Ant): number => {
    const neighbors = getNeighbors(ant.currentNode).filter(
      (n) => !ant.path.includes(n.node)
    );

    if (neighbors.length === 0) {
      // Dead end, go back
      return ant.path[ant.path.length - 2] || 0;
    }

    // Calculate probabilities using ACO formula
    const probabilities = neighbors.map((n) => {
      const pheromone = Math.pow(n.edge.pheromone, ALPHA);
      const heuristic = Math.pow(1 / n.edge.distance, BETA);
      return { node: n.node, prob: pheromone * heuristic };
    });

    const total = probabilities.reduce((sum, p) => sum + p.prob, 0);
    let random = Math.random() * total;

    for (const p of probabilities) {
      random -= p.prob;
      if (random <= 0) return p.node;
    }

    return probabilities[0].node;
  };

  /**
   * Calculate total path length
   */
  const calculatePathLength = (path: number[]): number => {
    let length = 0;
    for (let i = 0; i < path.length - 1; i++) {
      const from = path[i];
      const to = path[i + 1];
      const edge = edgesRef.current.find(
        (e) =>
          (e.from === from && e.to === to) || (e.from === to && e.to === from)
      );
      if (edge) length += edge.distance;
    }
    return length;
  };

  /**
   * Update pheromones after all ants complete
   */
  const updatePheromones = useCallback(() => {
    setCurrentPhase("Pheromone Update");

    // Evaporation
    edgesRef.current.forEach((edge) => {
      edge.pheromone *= 1 - EVAPORATION_RATE;
      edge.pheromone = Math.max(0.01, edge.pheromone);
    });

    let iterBestPath: number[] = [];
    let iterBestDistance = Infinity;

    // Deposit pheromones based on path quality
    antsRef.current.forEach((ant) => {
      if (ant.path.includes(9)) {
        // Reached food
        const pathLength = calculatePathLength(ant.path);
        const deposit = Q / pathLength;

        // Track iteration best
        if (pathLength < iterBestDistance) {
          iterBestDistance = pathLength;
          iterBestPath = [...ant.path];
        }

        // Update global best path
        if (bestDistance === null || pathLength < bestDistance) {
          setBestDistance(pathLength);
          setShortestPath([...ant.path]);
        }

        // Add pheromones to path
        for (let i = 0; i < ant.path.length - 1; i++) {
          const from = ant.path[i];
          const to = ant.path[i + 1];
          const edge = edgesRef.current.find(
            (e) =>
              (e.from === from && e.to === to) ||
              (e.from === to && e.to === from)
          );
          if (edge) {
            edge.pheromone += deposit;
          }
        }
      }
    });

    // Calculate average pheromone level
    const avgPheromone =
      edgesRef.current.reduce((sum, e) => sum + e.pheromone, 0) /
      edgesRef.current.length;

    // Log this iteration
    if (iterBestPath.length > 0) {
      const newLog: IterationLog = {
        iteration: iteration + 1,
        bestPath: iterBestPath,
        bestDistance: iterBestDistance,
        avgPheromone,
        timestamp: new Date(),
      };
      setIterationLogs((prev) => [...prev.slice(-19), newLog]); // Keep last 20 logs
    }
  }, [bestDistance, iteration, calculatePathLength]);

  /**
   * Main animation loop
   */
  const animate = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = "#f5f3ef";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const nodes = nodesRef.current;
    const edges = edgesRef.current;
    const ants = antsRef.current;

    // Draw edges with pheromone intensity
    edges.forEach((edge) => {
      const from = nodes[edge.from];
      const to = nodes[edge.to];
      const intensity = Math.min(edge.pheromone * 2, 1);

      // Check if this edge is part of shortest path
      const isShortestPath = shortestPath.some((node, i) => {
        if (i === 0) return false;
        const prev = shortestPath[i - 1];
        return (
          (edge.from === prev && edge.to === node) ||
          (edge.from === node && edge.to === prev)
        );
      });

      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);

      if (isShortestPath) {
        ctx.strokeStyle = `rgba(234, 179, 8, ${0.5 + intensity * 0.5})`;
        ctx.lineWidth = 4 + intensity * 4;
      } else {
        ctx.strokeStyle = `rgba(234, 179, 8, ${intensity * 0.6})`;
        ctx.lineWidth = 2 + intensity * 3;
      }
      ctx.stroke();
    });

    // Draw nodes
    nodes.forEach((node, index) => {
      ctx.beginPath();
      ctx.arc(node.x, node.y, index === 0 || index === 9 ? 20 : 12, 0, Math.PI * 2);

      if (index === 0) {
        ctx.fillStyle = "#8b5a2b"; // Nest - brown
      } else if (index === 9) {
        ctx.fillStyle = "#22c55e"; // Food - green
      } else {
        ctx.fillStyle = "#1f4d3a"; // Intermediate - dark green
      }
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.stroke();

      // Labels for nest and food
      if (index === 0 || index === 9) {
        ctx.fillStyle = "#fff";
        ctx.font = "bold 10px Inter";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(index === 0 ? "NEST" : "FOOD", node.x, node.y);
      }
    });

    // Update and draw ants
    let completed = 0;
    let allComplete = true;

    ants.forEach((ant) => {
      if (ant.currentNode !== 9 && !ant.returning) {
        allComplete = false;
        setCurrentPhase("Path Exploration");

        // Select next target if needed
        if (ant.targetNode === -1) {
          ant.targetNode = selectNextNode(ant);
        }

        // Move towards target
        const current = nodes[ant.currentNode];
        const target = nodes[ant.targetNode];
        const dx = target.x - current.x;
        const dy = target.y - current.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        ant.progress += (3 * speed) / dist;

        if (ant.progress >= 1) {
          // Arrived at target
          ant.currentNode = ant.targetNode;
          ant.path.push(ant.targetNode);
          ant.x = target.x;
          ant.y = target.y;
          ant.targetNode = -1;
          ant.progress = 0;
        } else {
          // Interpolate position
          ant.x = current.x + dx * ant.progress;
          ant.y = current.y + dy * ant.progress;
        }
      } else {
        completed++;
      }

      // Draw ant
      ctx.beginPath();
      ctx.arc(ant.x, ant.y, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#2d1810";
      ctx.fill();
    });

    setAntsCompleted(completed);

    // If all ants completed, update pheromones and reset
    if (allComplete) {
      updatePheromones();
      setIteration((prev) => prev + 1);

      // Reset ants for next iteration
      antsRef.current = Array.from({ length: NUM_ANTS }, () => ({
        x: nodes[0].x,
        y: nodes[0].y,
        path: [0],
        returning: false,
        currentNode: 0,
        targetNode: -1,
        progress: 0,
      }));
      setAntsCompleted(0);
    }

    if (isRunning) {
      animationRef.current = requestAnimationFrame(animate);
    }
  }, [isRunning, speed, shortestPath, updatePheromones]);

  /**
   * Start/stop simulation
   */
  const toggleSimulation = () => {
    setIsRunning((prev) => !prev);
  };

  /**
   * Reset simulation
   */
  const resetSimulation = () => {
    setIsRunning(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    initializeSimulation();
  };

  // Initialize on mount
  useEffect(() => {
    initializeSimulation();
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [initializeSimulation]);

  // Run animation when isRunning changes
  useEffect(() => {
    if (isRunning) {
      animationRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isRunning, animate]);

  // Format path for display
  const formatPath = (path: number[]): string => {
    return path.map((n) => (n === 0 ? "Nest" : n === 9 ? "Food" : `N${n}`)).join(" → ");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="section-title">
          Interactive <span className="text-gradient-pheromone">Simulation</span>
        </h1>
        <p className="section-subtitle max-w-2xl mx-auto">
          Watch ants discover the optimal path through pheromone communication
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Canvas Section */}
        <div className="lg:col-span-2 content-card">
          <canvas
            ref={canvasRef}
            width={700}
            height={400}
            className="simulation-canvas w-full"
          />

          {/* Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 mt-6">
            <div className="flex items-center gap-3">
              <button
                onClick={toggleSimulation}
                className="nav-button flex items-center gap-2"
              >
                {isRunning ? <Pause size={20} /> : <Play size={20} />}
                {isRunning ? "Pause" : "Start"}
              </button>
              <button
                onClick={resetSimulation}
                className="nav-button-secondary flex items-center gap-2"
              >
                <RotateCcw size={20} />
                Reset
              </button>
            </div>

            {/* Speed control */}
            <div className="speed-control">
              <label className="text-sm font-medium">Speed:</label>
              <input
                type="range"
                min="0.5"
                max="3"
                step="0.5"
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
                className="w-24 accent-primary"
              />
              <span className="text-sm text-muted-foreground">{speed}x</span>
            </div>
          </div>

          {/* Current Phase Indicator */}
          <div className="mt-4 p-3 rounded-lg bg-muted/50 flex items-center gap-3">
            <Zap size={18} className="text-secondary" />
            <span className="font-medium">Current Phase:</span>
            <span className="text-muted-foreground">{currentPhase}</span>
            <div className="ml-auto flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                Ants completed: {antsCompleted}/{NUM_ANTS}
              </span>
              <Progress value={(antsCompleted / NUM_ANTS) * 100} className="w-20 h-2" />
            </div>
          </div>
        </div>

        {/* Stats & Logs Panel */}
        <div className="space-y-4">
          {/* Stats Cards */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Simulation Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Iterations</span>
                <span className="text-xl font-bold text-primary">{iteration}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Best Distance</span>
                <span className="text-xl font-bold text-secondary">
                  {bestDistance ? Math.round(bestDistance) : "—"}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                <span className="text-sm text-muted-foreground">Ants</span>
                <span className="text-xl font-bold text-accent">{NUM_ANTS}</span>
              </div>
            </CardContent>
          </Card>

          {/* Best Path Display */}
          {shortestPath.length > 0 && (
            <Card className="border-secondary/50 bg-secondary/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Zap className="text-secondary" size={18} />
                  Optimal Path Found
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm font-mono bg-muted/50 p-3 rounded-lg break-words">
                  {formatPath(shortestPath)}
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Path length: {Math.round(bestDistance || 0)} units
                </p>
              </CardContent>
            </Card>
          )}

          {/* Iteration Logs */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Execution Log</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-48">
                {iterationLogs.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Start simulation to see iteration logs
                  </p>
                ) : (
                  <div className="space-y-2">
                    {iterationLogs.slice().reverse().map((log, idx) => (
                      <div
                        key={idx}
                        className="text-xs p-2 bg-muted/30 rounded border-l-2 border-primary/50"
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-semibold">Iteration {log.iteration}</span>
                          <span className="text-muted-foreground">
                            {log.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-muted-foreground">
                          Distance: {Math.round(log.bestDistance)} | 
                          Avg Pheromone: {log.avgPheromone.toFixed(3)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Legend */}
      <div className="content-card">
        <h3 className="font-semibold mb-4">Legend</h3>
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-nest" />
            <span className="text-sm">Nest (Start)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-food" />
            <span className="text-sm">Food (Goal)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-ant-dark" />
            <span className="text-sm">Ant</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-2 rounded-full bg-secondary" />
            <span className="text-sm">Pheromone Trail</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SimulationPage;
